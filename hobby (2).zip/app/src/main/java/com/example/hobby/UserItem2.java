package com.example.hobby;
public class UserItem2 {
    private int mImageResource;
    private String mTitle;
    private String mText;

    public UserItem2(int imageResource, String title, String text) {
        mImageResource = imageResource;
        mTitle = title;
        mText = text;
    }

    public int getImageResource() {
        return mImageResource;
    }

    public String getTitle() {
        return mTitle;
    }

    public String getText() {
        return mText;
    }
}

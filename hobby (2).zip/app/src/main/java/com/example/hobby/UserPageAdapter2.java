package com.example.hobby;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserPageAdapter2 extends RecyclerView.Adapter<UserPageAdapter2.UserViewHolder> {
    private Context mContext;
    private List<UserItem2> mUserList;
    private OnItemClickListener mListener;
    View dialogView;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mTextViewTitle;
        public TextView mTextViewText;
        public Button mButton;

        public UserViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.userPage_recyclerView2_profile);
            mTextViewTitle = itemView.findViewById(R.id.userPage_recyclerView2_title);
            mTextViewText = itemView.findViewById(R.id.userPage_recyclerView2_text);
            mButton = itemView.findViewById(R.id.userPage_recyclerView2_button);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public UserPageAdapter2(Context context, List<UserItem2> userList) {
        mContext = context;
        mUserList = userList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.userpage_recyclerview_item2, parent, false);
        return new UserViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        UserItem2 currentItem = mUserList.get(position);
        holder.mImageView.setImageResource(currentItem.getImageResource());
        holder.mTextViewTitle.setText(currentItem.getTitle());
        holder.mTextViewText.setText(currentItem.getText());
        // 버튼 클릭 이벤트 처리
        holder.mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(position);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(mContext);
                    dialogView = View.inflate(mContext, R.layout.review, null);
                    dlg.setView(dialogView);
                    dlg.setPositiveButton("확인",null);
                    dlg.show();

                    if (position == 0) {
                        Toast.makeText(mContext, "첫 번째 버튼이 눌렸습니다!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mUserList.size();
    }
}

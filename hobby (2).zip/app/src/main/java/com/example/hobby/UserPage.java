package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class UserPage extends AppCompatActivity {
    Button userPage_btn_modify, userPage_btn_history;


    private RecyclerView recyclerView;
    private UserPageAdapter adapter;
    private List<UserItem> userList;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_main);
        userPage_btn_modify=findViewById(R.id.userPage_btn_modify);
        userPage_btn_history=findViewById(R.id.userPage_btn_history);

        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("마이페이지");

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);

        recyclerView = findViewById(R.id.userPage_recyclerView);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        userList = new ArrayList<>();
        userList.add(new UserItem(R.drawable.dog, "2024년 05월 05일 어린이날 후기!!! 오늘은 좋은분과 만남을 가졌습니다..."));
        userList.add(new UserItem(R.drawable.dog, "어린이날에 정말 좋아요"));
        userList.add(new UserItem(R.drawable.dog, "와 나도 어린이!!"));

        adapter = new UserPageAdapter(userList, this);
        recyclerView.setAdapter(adapter);

        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(UserPage.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });



        userPage_btn_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserPage.this, UserPageSetting.class);
                startActivity(intent);
            }
        });

        userPage_btn_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserPage.this,UserPageHistory.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
         super.onOptionsItemSelected(item);
         int id= item.getItemId();
         if(id==R.id.action_myPage){
             Intent intent = new Intent(UserPage.this,MyPage.class);
             startActivity(intent);
         }
         return false;
    }
}

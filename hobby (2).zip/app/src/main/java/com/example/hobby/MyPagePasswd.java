package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MyPagePasswd extends AppCompatActivity {
    ImageButton back;
    Button change;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_mypage_passwd);
        back = findViewById(R.id.myPage_btn_back);
        change = findViewById(R.id.change);
        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("비밀번호 변경");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPagePasswd.this, MyPageAccount.class);
                startActivity(intent);
            }
        });
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dlg= new AlertDialog.Builder(MyPagePasswd.this);
                dlg.setMessage("변경하시겠습니까?");
                dlg.setPositiveButton("변경하기",null);
                dlg.setNegativeButton("취소",null);
                dlg.show();
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);


        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(MyPagePasswd.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
         return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id= item.getItemId();
        if(id==R.id.action_myPage){
            Intent intent = new Intent(MyPagePasswd.this,MyPage.class);
            startActivity(intent);
        }
        return false;
    }
}

package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MyPageAlarm extends AppCompatActivity {
    private RecyclerView mRecyclerView;

    private MyPageAlarmAdapter adapter;
    ImageButton back;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_mypage_alarm);
        mRecyclerView = findViewById(R.id.myPage_ListView);

        back = findViewById(R.id.myPage_btn_back);

        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("알림설정");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageAlarm.this, MyPage.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);


        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(MyPageAlarm.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });

        ArrayList<String> titles = new ArrayList<>();
        titles.add("알림 설정");
        titles.add("차단 관리");

        ArrayList<String> contents = new ArrayList<>();
        contents.add("확인하고자 하는 알림과 확인하고 싶지 않은 알림을 선택하세요.");
        contents.add("차단된 목록을 관리합니다.");


        adapter = new MyPageAlarmAdapter(this, titles, contents);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
        return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id= item.getItemId();
        if(id==R.id.action_myPage){
            Intent intent = new Intent(MyPageAlarm.this,MyPage.class);
            startActivity(intent);
        }
        return false;
    }
}

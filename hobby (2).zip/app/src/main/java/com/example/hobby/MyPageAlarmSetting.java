package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MyPageAlarmSetting extends AppCompatActivity {
    private RecyclerView mRecyclerView;


    ImageButton back;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_alarm_setting);

        mRecyclerView = findViewById(R.id.myPage_ListView);

        back = findViewById(R.id.myPage_btn_back);

        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("내 계정");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageAlarmSetting.this, MyPageAlarm.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);


        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(MyPageAlarmSetting.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });




    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
        return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id= item.getItemId();
        if(id==R.id.action_myPage){
            Intent intent = new Intent(MyPageAlarmSetting.this,MyPage.class);
            startActivity(intent);
        }
        return false;
    }
}

package com.example.hobby;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyPageAccountAdapter extends RecyclerView.Adapter<MyPageAccountAdapter.MyViewHolder> {
    private ArrayList<String> mTitles;
    private ArrayList<String> mContents;
    private int[] mImageResources = {R.drawable.mypage, R.drawable.key, R.drawable.hobby,R.drawable.location};
    private Context mContext;

    public MyPageAccountAdapter(Context context,  ArrayList<String> titles, ArrayList<String> contents) {
        mContext = context;
        mTitles = titles;
        mContents = contents;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.userpage_mypage_account_listview, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String title = mTitles.get(position);
        String content = mContents.get(position);
        int imageResource = mImageResources[position];

        holder.textTitle.setText(title);
        holder.textContent.setText(content);
        holder.imageView.setImageResource(imageResource);


    }

    @Override
    public int getItemCount() {
        return mTitles.size();

    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView imageView;
        public TextView textTitle;
        public TextView textContent;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textTitle = itemView.findViewById(R.id.text_title);
            textContent = itemView.findViewById(R.id.text_content);

            itemView.setOnClickListener(this); // 아이템 클릭 리스너 설정
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition(); // 클릭한 아이템 위치 가져오기
            if(position==0){
                Intent intent = new Intent(mContext, MyPageInformation.class);
                mContext.startActivity(intent);
            }
            if(position==1){
                Intent intent = new Intent(mContext,MyPagePasswd.class);
                mContext.startActivity(intent);
            }
            if(position==2){

            }
            if(position==3){

            }

        }
    }
}

package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MyPageAlarmBlocking extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private MyPageBlockingAdapter adapter;
    ImageButton back;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_alarm_blocking);

        mRecyclerView = findViewById(R.id.myPage_ListView);

        back = findViewById(R.id.myPage_btn_back);

        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("차단 설정");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageAlarmBlocking.this, MyPageAlarm.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);


        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(MyPageAlarmBlocking.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });

        ArrayList<String> contents = new ArrayList<>();
        contents.add("호날두");
        contents.add("크리스티아노");
        contents.add("날강두");
        contents.add("노쇼두");
        contents.add("상암두");
        contents.add("스포르팅두");
        contents.add("신밧두");

        adapter = new MyPageBlockingAdapter(this,contents);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
        return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id= item.getItemId();
        if(id==R.id.action_myPage){
            Intent intent = new Intent(MyPageAlarmBlocking.this,MyPage.class);
            startActivity(intent);
        }
        return false;
    }
}

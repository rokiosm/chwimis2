package com.example.hobby;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyPageAdapter extends RecyclerView.Adapter<MyPageAdapter.MyViewHolder> {
    private ArrayList<String> mAccounts;
    private Context mContext;

    public MyPageAdapter(Context context, ArrayList<String> accounts) {
        mContext = context;
        mAccounts = accounts;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.userpage_listview_mypage, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String account = mAccounts.get(position);
        holder.textViewAccount.setText(account);
    }

    @Override
    public int getItemCount() {
        return mAccounts.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textViewAccount;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAccount = itemView.findViewById(R.id.userPage_myPage_text);
            itemView.setOnClickListener(this); // 아이템 클릭 리스너 설정
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition(); // 클릭한 아이템 위치 가져오기
            String account = mAccounts.get(position); // 해당 위치의 데이터 가져오기
            if(position==0){
                Intent intent = new Intent(mContext, MyPageAccount.class);
                mContext.startActivity(intent);
            }
            if(position==1){
                Intent intent = new Intent(mContext, MyPageAlarm.class);
                mContext.startActivity(intent);
            }
            if(position==2){
                Intent intent = new Intent(mContext, MyPageNotify.class);
                mContext.startActivity(intent);
            }
            if(position==3){

            }

        }
    }
}

package com.example.hobby;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class UserPageHistory extends AppCompatActivity {
    Button profile ;
    private RecyclerView mRecyclerView;
    private UserPageAdapter2 mAdapter;
    private List<UserItem2> mUserList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpage_main_history);

        profile=findViewById(R.id.userPage_btn_profile);
        Toolbar toolbar = findViewById(R.id.userpage_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("마이페이지");
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.action_mypage);

        // 리사이클러뷰 설정
        mRecyclerView = findViewById(R.id.userPage_recyclerView2);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 데이터 설정
        mUserList = new ArrayList<>();
        mUserList.add(new UserItem2(R.drawable.dog, "안녕하세요!!", "어린이날 행사 같이 하실분 구해요!! 정말 좋은시간 보낼 수 있는 기회입니다.!!"));
        mUserList.add(new UserItem2(R.drawable.dog, "안녕하세요!!", "어린이날 행사 같이 하실분 구해요!! 정말 좋은시간 보낼 수 있는 기회입니다.!!"));
        mUserList.add(new UserItem2(R.drawable.dog, "안녕하세요!!", "어린이날 행사 같이 하실분 구해요!! 정말 좋은시간 보낼 수 있는 기회입니다.!!"));

        // 어댑터 설정
        mAdapter = new UserPageAdapter2(this, mUserList);
        mRecyclerView.setAdapter(mAdapter);

        // 리사이클러뷰 아이템 클릭 리스너 설정
        mAdapter.setOnItemClickListener(new UserPageAdapter2.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // 클릭 이벤트 처리
                // 예: 리사이클러뷰 아이템을 클릭했을 때 원하는 동작 수행
            }
        });

        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.action_home) {
                    startActivity(new Intent(UserPageHistory.this, MainActivity.class));
                    finish();
                    return true;
                }

                return false;
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserPageHistory.this, UserPage.class);
                startActivity(intent);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mypage_toolbar,menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id= item.getItemId();
        if(id==R.id.action_myPage){
            Intent intent = new Intent(UserPageHistory.this,MyPage.class);
            startActivity(intent);
        }
        return false;
    }
}

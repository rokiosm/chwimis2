package com.example.hobby2.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hobby2.R;

public class activity_loginandsign extends AppCompatActivity {

    Button loginbtn,joinbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginandsign);

        loginbtn=findViewById(R.id.loginbtn);
        joinbtn=findViewById(R.id.joinbtn);

        loginbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent loginandsign=new Intent(activity_loginandsign.this,activity_loginpage.class);
                        startActivity(loginandsign);

            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signpage=new Intent(activity_loginandsign.this,activity_signinpage.class);
                startActivity(signpage);

            }
        });
    }
}
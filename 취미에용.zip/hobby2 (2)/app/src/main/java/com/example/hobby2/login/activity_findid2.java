package com.example.hobby2.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hobby2.R;

public class activity_findid2 extends AppCompatActivity {
    Button btnnext;
    ImageButton backbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findid2);

        btnnext=findViewById(R.id.btnnext);

        backbtn=findViewById(R.id.backbtn);

       btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextIntent=new Intent(activity_findid2.this,activity_findid3.class);
                startActivity(nextIntent);

            }
        });

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(activity_findid2.this,activity_findid.class);
                startActivity(backIntent);
            }
        });
    }
}
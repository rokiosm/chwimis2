package com.example.hobby2.mypage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;

public class UserPageNotifyFragment extends Fragment {
    ImageButton back;
    private RecyclerView mRecyclerView;
    private UserPageNotifyAdapter mAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View view =inflater.inflate(R.layout.fragment_user_page_notify, container, false);
       mRecyclerView= view.findViewById(R.id.myPage_ListView);

       back=view.findViewById(R.id.btn_back);
        ArrayList<String> titles = new ArrayList<>();
        titles.add("[공지] 공지입니다.");
        titles.add("[공지] 공지입니다.");
        titles.add("[답변] QnA답변입니다.");


        ArrayList<String> contents = new ArrayList<>();
        contents.add("2024.04.11");
        contents.add("2024.04.15");
        contents.add("2024.04.20");

        // 어댑터 생성 및 설정
        mAdapter = new UserPageNotifyAdapter(getActivity(), titles, contents);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new UserPageFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        return view;
    }
}
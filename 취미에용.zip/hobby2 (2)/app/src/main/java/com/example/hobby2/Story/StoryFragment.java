package com.example.hobby2.Story;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.Arrays;
import java.util.List;


public class StoryFragment extends Fragment {
    private RecyclerView recyclerView;
    private StoryitemAdapter storyItemAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_story, container, false);

        recyclerView = view.findViewById(R.id.recycle); // 레이아웃 파일에서 RecyclerView의 ID 확인 필요
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity())); // LinearLayoutManager를 사용, 다른 레이아웃 매니저도 선택 가능
        List<String> comments = Arrays.asList("Great story!", "Wow!", "Thanks for sharing!");
        List<String> likes = Arrays.asList("100 likes", "200 likes", "150 likes");
        // 어댑터 설정
        storyItemAdapter = new StoryitemAdapter(getActivity(), comments, likes);
        recyclerView.setAdapter(storyItemAdapter);
        // BottomNavigationView 초기화 및 클릭 리스너 설정
        return view;
    }
}
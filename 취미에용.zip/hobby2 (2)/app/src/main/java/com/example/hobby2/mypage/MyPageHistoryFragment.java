package com.example.hobby2.mypage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;

public class MyPageHistoryFragment extends Fragment {
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private ArrayList<String> title;

    private ArrayList<String> text;

    Button myPageBtn;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_page_history, container, false);

        recyclerView = view.findViewById(R.id.userPage_recyclerView2);
        myPageBtn= view.findViewById(R.id.userPage_btn_profile);
        // 히스토리 데이터 생성
        title = new ArrayList<>();
        title.add("어린이");
        title.add("어른이");

        text = new ArrayList<>();
        text.add("안녕하세요!!");
        text.add("어린이날 행사 같이 하실분 구해요!! 정말 좋은시간 보낼 수 있는 기회입니다.!!");
        adapter = new HistoryAdapter(getActivity(),title,text);
        recyclerView.setAdapter(adapter);


        myPageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new MyPageFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        return view;
    }
}

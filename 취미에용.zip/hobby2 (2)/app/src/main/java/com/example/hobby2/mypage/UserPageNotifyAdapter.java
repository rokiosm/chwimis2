package com.example.hobby2.mypage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;

public class UserPageNotifyAdapter extends RecyclerView.Adapter<UserPageNotifyAdapter.MyViewHolder> {
    private ArrayList<String> mTitles;
    private ArrayList<String> mContents;
    private Context mContext;

    public UserPageNotifyAdapter(Context context, ArrayList<String> titles, ArrayList<String> contents) {
        mContext = context;
        mTitles = titles;
        mContents = contents;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_notify, parent, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String title = mTitles.get(position);
        String content = mContents.get(position);
        holder.textTitle.setText(title);
        holder.textContent.setText(content);

    }

    @Override
    public int getItemCount() {
        return mTitles.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView textTitle;
        public TextView textContent;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.myPage_title);
            textContent = itemView.findViewById(R.id.myPage_date);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position==0){

                    }
                }
            });
        }
    }
}

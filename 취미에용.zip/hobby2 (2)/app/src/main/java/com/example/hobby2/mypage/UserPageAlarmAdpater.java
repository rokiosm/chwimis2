package com.example.hobby2.mypage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;

public class UserPageAlarmAdpater extends RecyclerView.Adapter<UserPageAlarmAdpater.ViewHolder> {
    private Context context;
    private  ArrayList<String> titles;
    private  ArrayList<String> contents;
    private int[] ImageResources = {R.drawable.alarm,R.drawable.block};

    public UserPageAlarmAdpater(Context context, ArrayList<String> titles, ArrayList<String> contents) {
        this.context = context;
        this.titles = titles;
        this.contents = contents;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_user_alarm,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String title = titles.get(position);
        String content = contents.get(position);
        int imageResource = ImageResources[position];

        holder.title.setText(title);
        holder.text.setText(content);
        holder.imageView.setImageResource(imageResource);

    }

    @Override
    public int getItemCount() {
        return titles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView title;
        private TextView text;
        public ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            title = (TextView)itemView.findViewById(R.id.text_title);
            text = (TextView)itemView.findViewById(R.id.text_content);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(position==0){
                        replaceFragment(new UserPageAlarmSettingFragment());
                    }
                    if(position ==1){
                        replaceFragment(new UserPageAlarmBlockFragment());
                    }
                }
            });
        }
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_content, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}

package com.example.hobby2.mypage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;

public class UserPageAdapter extends RecyclerView.Adapter<UserPageAdapter.MyViewHolder> {
    private ArrayList<String> mAccounts;
    private Context mContext;

    public UserPageAdapter(Context context, ArrayList<String> accounts) {
        mContext = context;
        mAccounts = accounts;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_user_page, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String account = mAccounts.get(position);
        holder.textViewAccount.setText(account);
    }

    @Override
    public int getItemCount() {
        return mAccounts.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textViewAccount;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAccount = itemView.findViewById(R.id.userPage_myPage_text);
            itemView.setOnClickListener(this); // 아이템 클릭 리스너 설정
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition(); // 클릭한 아이템 위치 가져오기
            String account = mAccounts.get(position); // 해당 위치의 데이터 가져오기
            if(position==0){
                replaceFragment(new UserPageAccount());
            }
            if(position==1){
                replaceFragment(new UserPageAlarmFragment());
            }
            if(position==2){
                replaceFragment(new UserPageNotifyFragment());
            }
            if(position==3){

            }

        }
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = ((AppCompatActivity) mContext).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_content, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}

package com.example.hobby2.mypage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hobby2.R;

import java.util.ArrayList;


public class UserPageAlarmBlockFragment extends Fragment {
    ImageButton back;
    private RecyclerView mRecyclerView;
    private UserPageAlarmBlockAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_page_alarm_block, container, false);
        back=view.findViewById(R.id.btn_back);
        mRecyclerView = view.findViewById(R.id.myPage_ListView);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new UserPageAlarmFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        ArrayList<String> contents = new ArrayList<>();
        contents.add("호날두");
        contents.add("크리스티아노");
        contents.add("날강두");
        contents.add("노쇼두");
        contents.add("상암두");
        contents.add("스포르팅두");
        contents.add("신밧두");

        adapter = new UserPageAlarmBlockAdapter(getActivity(),contents);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        return view;
    }
}
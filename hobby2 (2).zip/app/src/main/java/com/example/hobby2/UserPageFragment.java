package com.example.hobby2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;


public class UserPageFragment extends Fragment {
     ImageButton back;
    RecyclerView recyclerView;
    UserPageAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      View view = inflater.inflate(R.layout.fragment_user_page, container, false);

      back = view.findViewById(R.id.btn_back);
      back.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              FragmentManager fragmentManager = getParentFragmentManager();
              FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
              fragmentTransaction.replace(R.id.main_content, new MyPageFragment());
              fragmentTransaction.addToBackStack(null);
              fragmentTransaction.commit();
          }
      });


       recyclerView = view.findViewById(R.id.myPage_ListView);

        ArrayList<String> accountList = new ArrayList<>();
        accountList.add("내 계정");
        accountList.add("알림설정");
        accountList.add("공지사항");
        accountList.add("의견남기기");

        adapter = new UserPageAdapter(getActivity(),accountList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
      return view;
    }
}
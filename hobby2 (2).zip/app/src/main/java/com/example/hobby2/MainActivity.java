package com.example.hobby2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.hobby2.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    boolean isMyPageSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("취밋");
        replaceFragment(new HomeFragment());
        binding.bottomNavigation.setBackground(null);

        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.action_home) {
                replaceFragment(new HomeFragment());
                isMyPageSelected = false;
            } else if (item.getItemId() == R.id.action_chatting) {
                replaceFragment(new ChattingFragment());
                isMyPageSelected = false;
            } else if (item.getItemId() == R.id.action_enroll) {
                replaceFragment(new EnrollFragment());
                isMyPageSelected = false;
            } else if (item.getItemId() == R.id.action_story) {
                replaceFragment(new StoryFragment());
                isMyPageSelected = false;
            } else if (item.getItemId() == R.id.action_mypage) {
                replaceFragment(new MyPageFragment());
                isMyPageSelected = true;
            }
            invalidateOptionsMenu();
            return true;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        if (isMyPageSelected) {
            menuInflater.inflate(R.menu.mypage_toolbar, menu);
        } else {
            menuInflater.inflate(R.menu.toolbar_navigation_main, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        if(item.getItemId() ==R.id.action_userPage){
            replaceFragment(new UserPageFragment());
            isMyPageSelected = true;
        }
        return false;
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_content, fragment);
        fragmentTransaction.commit();
    }
}


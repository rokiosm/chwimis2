package com.example.hobby2;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class MyPageFragment extends Fragment {

    private RecyclerView recyclerView;
    private MypageAdapter adapter;
    private ArrayList<String> contents;
    Button historyButton,profileSetting;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_page, container, false);

        recyclerView = view.findViewById(R.id.userPage_recyclerView);
        profileSetting =view.findViewById(R.id.btn_profile_setting);
        historyButton = view.findViewById(R.id.btn_history);

        contents = new ArrayList<>();
        contents.add("2024년 05월 05일 어린이날 후기!!! 오늘은 좋은분과 만남을 가졌습니다...");
        contents.add("2024년 05월 06일 피크닉을 다녀왔어요! 날씨도 좋았고, 친구들과 즐거운 시간을 보냈습니다.");
        contents.add("2024년 05월 07일 오늘은 영화를 봤어요. 너무 재미있었습니다.");

        adapter = new MypageAdapter(getActivity(), contents);
        recyclerView.setAdapter(adapter);


        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new MyPageHistoryFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        profileSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),MyPageProfile.class);
                startActivity(intent);
            }
        });

        return view;
    }
}

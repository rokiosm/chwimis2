package com.example.hobby2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private ArrayList<String> titleList;
    private ArrayList<String> textList;
    private Context context;
    View dialogView;


    public HistoryAdapter(Context context, ArrayList<String> titleList, ArrayList<String> textList) {
        this.context = context;
        this.titleList = titleList;
        this.textList = textList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String title = titleList.get(position);
        String text = textList.get(position);
        holder.titleTextView.setText(title);
        holder.textTextView.setText(text);

        // 버튼 클릭 리스너 설정
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dlg = new AlertDialog.Builder(context);
                dialogView = View.inflate(context, R.layout.dialog_review, null);
                dlg.setView(dialogView);
                dlg.setPositiveButton("확인",null);
                dlg.show();

            }
        });
    }

    @Override
    public int getItemCount() {
        return titleList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView textTextView;
        Button button;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.userPage_recyclerView2_title);
            textTextView = itemView.findViewById(R.id.userPage_recyclerView2_text);
            button = itemView.findViewById(R.id.userPage_recyclerView2_button);
        }
    }
}


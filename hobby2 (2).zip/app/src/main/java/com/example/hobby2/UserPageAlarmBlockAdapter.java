package com.example.hobby2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserPageAlarmBlockAdapter extends RecyclerView.Adapter<UserPageAlarmBlockAdapter.ViewHolder> {
    private Context context;
    private  ArrayList<String> contents;

    private int[] imageResource = {R.drawable.ho,R.drawable.ho2,R.drawable.ho3,R.drawable.ho4,R.drawable.ho5,R.drawable.ho6,R.drawable.ho7};
    public UserPageAlarmBlockAdapter(Context context, ArrayList<String> contents) {
        this.context = context;
        this.contents = contents;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_user_block    ,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String content = contents.get(position);
        int image = imageResource[position];

        holder.text.setText(content);
        holder.imageView.setImageResource(image);
    }

    @Override
    public int getItemCount() {
        return contents.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView text;
        public ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            text = (TextView)itemView.findViewById(R.id.blocking);
            imageView =itemView.findViewById(R.id.blocking_profile);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                   for(int i= 0; i<imageResource.length; i++){
                       if(position ==i){
                           AlertDialog.Builder dlg= new AlertDialog.Builder(context);
                           dlg.setMessage("차단을 해제하시겠습니까?");
                           dlg.setPositiveButton("해제",null);
                           dlg.setNegativeButton("취소",null);
                           dlg.show();
                       }
                   }
                }
            });
        }
    }
}

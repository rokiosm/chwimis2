package com.example.hobby2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;


public class UserPageAccount extends Fragment {
    private RecyclerView RecyclerView;
    private UserAccountAdapter Adapter;
    ImageButton back;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_user_page_account, container, false);
        back= view.findViewById(R.id.btn_back);
        RecyclerView = view.findViewById(R.id.myPage_ListView);
        ArrayList<String> titles = new ArrayList<>();
        titles.add("계정 정보");
        titles.add("비밀번호 변경하기");
        titles.add("취미 변경하기");
        titles.add("위치 정보 변경하기");

        ArrayList<String> contents = new ArrayList<>();
        contents.add("휴대폰 번호와 이메일 주소와 같은 계정정보를 조회합니다");
        contents.add("언제든지 비밀번호를 변경하세요");
        contents.add("취미를 변경하거나 선택합니다");
        contents.add("위치 정보를 변경합니다");

        // 어댑터 생성 및 설정
        Adapter = new UserAccountAdapter(getActivity(), titles, contents);
        RecyclerView.setAdapter(Adapter);
        RecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new UserPageFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        return view;
    }
}
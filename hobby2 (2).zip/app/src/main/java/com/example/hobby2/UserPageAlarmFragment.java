package com.example.hobby2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import java.util.ArrayList;


public class UserPageAlarmFragment extends Fragment {
    private RecyclerView mRecyclerView;

    private UserPageAlarmAdpater adapter;
    ImageButton back;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View view =inflater.inflate(R.layout.fragment_user_page_alarm, container, false);
        back=view.findViewById(R.id.btn_back);
        mRecyclerView = view.findViewById(R.id.myPage_ListView);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getParentFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_content, new UserPageFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        ArrayList<String> titles = new ArrayList<>();
        titles.add("알림 설정");
        titles.add("차단 관리");

        ArrayList<String> contents = new ArrayList<>();
        contents.add("확인하고자 하는 알림과 확인하고 싶지 않은 알림을 선택하세요.");
        contents.add("차단된 목록을 관리합니다.");


        adapter = new UserPageAlarmAdpater(getActivity(), titles, contents);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return view;
    }
}
package kec.mjc.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class activity_findpasswd extends AppCompatActivity {
    Button sendmailbtn;
    ImageButton backbtn;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findpasswd);

        sendmailbtn=findViewById(R.id.sendmailbtn);
        backbtn=findViewById(R.id.backbtn);

        sendmailbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent movetologin=new Intent(activity_findpasswd.this,activity_loginpage.class);
                startActivity(movetologin);

            }
        });
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(activity_findpasswd.this,activity_findid.class);
                startActivity(backIntent);
            }
        });

    }
}

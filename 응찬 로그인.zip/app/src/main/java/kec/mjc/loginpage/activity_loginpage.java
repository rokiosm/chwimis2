package kec.mjc.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class activity_loginpage extends AppCompatActivity {
    Button findidbtn,loginbtn;
    ImageButton backbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        loginbtn=findViewById(R.id.loginbtn);
        findidbtn=findViewById(R.id.findidbtn);
        backbtn=findViewById(R.id.backbtn);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginandsign=new Intent(activity_loginpage.this,activity_loginandsign.class);
                startActivity(loginandsign);

            }
        });
        findidbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signpage=new Intent(activity_loginpage.this,activity_findid.class);
                startActivity(signpage);

            }
        });
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(activity_loginpage.this,activity_loginandsign.class);
                startActivity(backIntent);
            }
        });
    }
}
package kec.mjc.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class activity_findid3 extends AppCompatActivity {
    Button movetologinbtn;
    ImageButton backbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findid3);


        movetologinbtn=findViewById(R.id.movetologinbtn);
        backbtn=findViewById(R.id.backbtn);

        movetologinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent movetologin=new Intent(activity_findid3.this,activity_loginpage.class);
                startActivity(movetologin);

            }
        });
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(activity_findid3.this,activity_findid2.class);
                startActivity(backIntent);
            }
        });

    }
}